#pragma once
#include "Map.h"
#include <conio.h>

void test();