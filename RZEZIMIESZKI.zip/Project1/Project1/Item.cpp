#include <string>
#include "Item.h"
using std::string;

Item::Item(string name) : name(name) {};
