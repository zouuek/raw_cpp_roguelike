#pragma once
#include <string>
using std::string;

class Item {
public:
	string name;
	Item(string name);
};